package com.example.ikhsanefendi.quizkelompok1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button myDeskripsi;
    private Button myFasilitas;
    private Button myGambar;
    private Button myOpini;
    private Button myPeta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDeskripsi = (Button) findViewById(R.id.buttondeskripsi); //menyatakan bahwa id button profil disimpan pada object myProfil
        myDeskripsi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Deskripsi.class); // berpindah halaman dan kelas, bahwa halaman yang dituju adalah main2activity
                startActivity(i);

            }
        });
        myFasilitas = (Button) findViewById(R.id.ButtonFasilitas); //menyatakan bahwa id button profil disimpan pada object myProfil
        myFasilitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Fasilitas.class);
                startActivity(i);

            }
        });
        myGambar = (Button) findViewById(R.id.ButtonGambar); //menyatakan bahwa id button profil disimpan pada object myProfil
        myGambar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Gambar.class);
                startActivity(i);

            }
        });
        myOpini = (Button) findViewById(R.id.ButtonOpini); //menyatakan bahwa id button profil disimpan pada object myProfil
        myOpini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Opini.class);
                startActivity(i);

            }
        });

//        myPeta = (Button) findViewById(R.id.facebook);
//        myPeta.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri uri = Uri.parse("maps.google.com");
//                Intent i = new Intent(Intent.ACTION_VIEW, uri);
//                startActivity(i);
//            }
//        });
    }
}
